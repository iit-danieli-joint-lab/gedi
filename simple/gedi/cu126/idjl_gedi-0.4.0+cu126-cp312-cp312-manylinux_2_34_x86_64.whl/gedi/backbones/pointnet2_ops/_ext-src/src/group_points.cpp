#include "group_points.h"
#include "group_points_cpu.h"
#include "utils.h"

#ifdef WITH_CUDA
void group_points_kernel_wrapper(int b, int c, int n, int npoints, int nsample,
                                 const float *points, const int *idx,
                                 float *out);

void group_points_grad_kernel_wrapper(int b, int c, int n, int npoints,
                                      int nsample, const float *grad_out,
                                      const int *idx, float *grad_points);
#endif

at::Tensor group_points(at::Tensor points, at::Tensor idx)
{
  CHECK_CONTIGUOUS(points);
  CHECK_CONTIGUOUS(idx);
  CHECK_IS_FLOAT(points);
  CHECK_IS_INT(idx);

  if (points.is_cuda())
  {
    CHECK_CUDA(idx);

#ifdef WITH_CUDA
    at::Tensor output =
        torch::zeros({points.size(0), points.size(1), idx.size(1), idx.size(2)},
                     at::device(points.device()).dtype(at::ScalarType::Float));

    group_points_kernel_wrapper(points.size(0), points.size(1), points.size(2),
                                idx.size(1), idx.size(2),
                                points.data_ptr<float>(), idx.data_ptr<int>(),
                                output.data_ptr<float>());

    return output;
#else
    TORCH_CHECK(false, "Not compiled with CUDA support");
#endif
  }
  else
  {
    at::Tensor output =
        torch::zeros({points.size(0), points.size(1), idx.size(1), idx.size(2)},
                     at::device(points.device()).dtype(at::ScalarType::Float));

    group_points_cpu(points.size(0), points.size(1), points.size(2),
                     idx.size(1), idx.size(2),
                     points.data_ptr<float>(), idx.data_ptr<int>(),
                     output.data_ptr<float>());

    return output;
  }
}

at::Tensor group_points_grad(at::Tensor grad_out, at::Tensor idx, const int n)
{
  CHECK_CONTIGUOUS(grad_out);
  CHECK_CONTIGUOUS(idx);
  CHECK_IS_FLOAT(grad_out);
  CHECK_IS_INT(idx);

  if (grad_out.is_cuda())
  {
    CHECK_CUDA(idx);

#ifdef WITH_CUDA
    at::Tensor output =
        torch::zeros({grad_out.size(0), grad_out.size(1), n},
                     at::device(grad_out.device()).dtype(at::ScalarType::Float));

    group_points_grad_kernel_wrapper(
        grad_out.size(0), grad_out.size(1), n, idx.size(1), idx.size(2),
        grad_out.data_ptr<float>(), idx.data_ptr<int>(),
        output.data_ptr<float>());

    return output;
#else
    TORCH_CHECK(false, "Not compiled with CUDA support");
#endif
  }
  else
  {
    at::Tensor output =
        torch::zeros({grad_out.size(0), grad_out.size(1), n},
                     at::device(grad_out.device()).dtype(at::ScalarType::Float));

    group_points_grad_cpu(grad_out.size(0), grad_out.size(1), n, idx.size(1), idx.size(2),
                          grad_out.data_ptr<float>(), idx.data_ptr<int>(),
                          output.data_ptr<float>());

    return output;
  }
}
